<?php

    $db = mysqli_connect("localhost","root","","perpus") or die("mysql not connect");